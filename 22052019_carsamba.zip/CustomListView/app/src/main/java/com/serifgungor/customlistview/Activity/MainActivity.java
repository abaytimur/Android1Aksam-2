package com.serifgungor.customlistview.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.serifgungor.customlistview.Adapter.MeyveAdapter;
import com.serifgungor.customlistview.Model.Meyve;
import com.serifgungor.customlistview.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Meyve> meyveler = new ArrayList<>();
    MeyveAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        meyveler.add(new Meyve(R.drawable.erik,"Erik","Erik açıklama"));
        meyveler.add(new Meyve(R.drawable.elma,"Elma","Elma açıklama"));
        meyveler.add(new Meyve(R.drawable.kivi,"Kivi","Kivi açıklama"));
        meyveler.add(new Meyve(R.drawable.karpuz,"Karpuz","Karpuz açıklama"));
        meyveler.add(new Meyve(R.drawable.kiraz,"Kiraz","Kiraz açıklama"));
        meyveler.add(new Meyve(R.drawable.visne,"Vişne","Vişne açıklama"));
        meyveler.add(new Meyve(R.drawable.portakal,"Portakal","Portakal açıklama"));
        meyveler.add(new Meyve(R.drawable.nar,"Nar","Nar açıklama"));

        adapter = new MeyveAdapter(getApplicationContext(),meyveler);
        listView.setAdapter(adapter);



    }
}
