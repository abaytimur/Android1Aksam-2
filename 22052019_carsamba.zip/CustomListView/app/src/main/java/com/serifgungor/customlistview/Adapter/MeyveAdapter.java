package com.serifgungor.customlistview.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.customlistview.Model.Meyve;
import com.serifgungor.customlistview.R;

import java.util.ArrayList;

public class MeyveAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Meyve> meyveler;

    public MeyveAdapter(){}

    public MeyveAdapter(Context context,ArrayList<Meyve> meyveler){
        this.context = context;
        this.meyveler = meyveler;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        //Arraylist'in eleman sayısını döndürmesi gerekir.
        return meyveler.size();
    }

    @Override
    public Object getItem(int position) {
        // Kaçıncı item'da olduğumuz bilgisini iletir.
        return meyveler.get(position);
    }

    @Override
    public long getItemId(int position) {
        // Kaçıncı indiste olduğumuz bilgisini iletir.
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Satır görüntüsünü oluşturma, satır görüntüsündeki nesneleri tanımlama işlemini sağlar.
        //Satıra tıklanma olayı da burada sağlanabilir.
        View view = layoutInflater.inflate(R.layout.custom_row,null);

        ImageView ivResim = view.findViewById(R.id.ivResim);
        TextView tvBaslik = view.findViewById(R.id.tvBaslik);
        TextView tvAciklama = view.findViewById(R.id.tvAciklama);

        //Drawable klasörü içerisinden modelin değişkeninde belirttiğimiz resim dosyasını
        //imageView nesnesinde gösterir.
        ivResim.setImageResource(meyveler.get(position).getResim());
        tvBaslik.setText(meyveler.get(position).getIsim());
        tvAciklama.setText(meyveler.get(position).getAciklama());

        return view;
    }
}
