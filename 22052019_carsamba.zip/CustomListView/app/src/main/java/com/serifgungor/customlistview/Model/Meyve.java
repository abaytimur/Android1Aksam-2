package com.serifgungor.customlistview.Model;

public class Meyve {
    private int resim;
    private String isim;
    private String aciklama;

    public Meyve() {
    }

    public Meyve(int resim, String isim, String aciklama) {
        this.resim = resim;
        this.isim = isim;
        this.aciklama = aciklama;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }
    /*
    OOP
      Kapsülleme (Encapsulation / Model)
      - Değişkenlerin private tanımlanması
      - Boş ve dolu constructorlar üretilmesi
      - get ve set metotlar üretilmesi
     */

}
