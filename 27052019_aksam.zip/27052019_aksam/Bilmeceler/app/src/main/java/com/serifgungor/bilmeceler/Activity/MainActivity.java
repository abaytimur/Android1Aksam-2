package com.serifgungor.bilmeceler.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.serifgungor.bilmeceler.Adapter.AdapterBilmeceler;
import com.serifgungor.bilmeceler.Model.Kategori;
import com.serifgungor.bilmeceler.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    AdapterBilmeceler adapterBilmeceler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        //int id, String baslik, String bilmeceSayisi, String emoji
        kategoriler.add(new Kategori(1,"Komik Bilmeceler","928 Adet","\uD83D\uDE02"));
        kategoriler.add(new Kategori(2,"Klasik Bilmeceler","928 Adet","\uD83D\uDE02"));
        kategoriler.add(new Kategori(3,"İlginç Bilmeceler","928 Adet","\uD83D\uDE02"));
        kategoriler.add(new Kategori(4,"Şaşırtan Bilmeceler","928 Adet","\uD83D\uDE02"));
        kategoriler.add(new Kategori(5,"Zorlayan Bilmeceler","928 Adet","\uD83D\uDE02"));
        kategoriler.add(new Kategori(6,"Zeka Soruları","928 Adet","\uD83D\uDE02"));
        kategoriler.add(new Kategori(7,"Saçmalayan Bilmeceler","928 Adet","\uD83D\uDE02"));

        adapterBilmeceler = new AdapterBilmeceler(getApplicationContext(),kategoriler);
        listView.setAdapter(adapterBilmeceler);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                Intent intent = new Intent(getApplicationContext(),BilmecelerActivity.class);
                intent.putExtra("kategori",kategoriler.get(position));
                startActivity(intent);


            }
        });



    }
}
