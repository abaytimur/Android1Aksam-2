package com.serifgungor.bilmeceler.Model;

import java.io.Serializable;

public class Kategori implements Serializable {
    private int id;
    private String baslik;
    private String bilmeceSayisi;
    private String emoji;

    public Kategori() {
    }

    public Kategori(int id, String baslik, String bilmeceSayisi, String emoji) {
        this.id = id;
        this.baslik = baslik;
        this.bilmeceSayisi = bilmeceSayisi;
        this.emoji = emoji;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getBilmeceSayisi() {
        return bilmeceSayisi;
    }

    public void setBilmeceSayisi(String bilmeceSayisi) {
        this.bilmeceSayisi = bilmeceSayisi;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }

    /*
    Kapsülleme ilkesi
    - değişkenlerin private tanımlanması
    - her bir değişken için get-set metot üretilmesi
    - boş ve dolu constructor üretilmesi
     */

}
