package com.serifgungor.bilmeceler.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.serifgungor.bilmeceler.Model.Kategori;
import com.serifgungor.bilmeceler.R;

import java.util.ArrayList;

public class AdapterBilmeceler extends BaseAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Kategori> kategoriler;

    public AdapterBilmeceler() {
    }

    public AdapterBilmeceler(Context context, ArrayList<Kategori> kategoriler) {
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.kategoriler = kategoriler;
    }

    @Override
    public int getCount() {
        //Listenin eleman sayısını döner
        return kategoriler.size();
    }

    @Override
    public Object getItem(int position) {
        //Listenin ilgili indisindeki modeli döndürür.
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        /*
        Satır görüntüsünün layout'a bağlanması, nesnelerin referanslarının
        tanımlanması işlemini yapar.
         */
        View v = layoutInflater.inflate(R.layout.kategori_satirgoruntusu,null);

        TextView tvBaslik,tvEmoji,tvBilmeceSayisi;

        tvBaslik = v.findViewById(R.id.tvBaslik);
        tvEmoji = v.findViewById(R.id.tvEmoji);
        tvBilmeceSayisi = v.findViewById(R.id.tvBilmeceSayisi);

        tvBaslik.setText(kategoriler.get(position).getBaslik());
        tvEmoji.setText(kategoriler.get(position).getEmoji());
        tvBilmeceSayisi.setText(kategoriler.get(position).getBilmeceSayisi());

        return v;
    }

}
