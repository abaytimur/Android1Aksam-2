package com.serifgungor.bilmeceler.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.serifgungor.bilmeceler.Model.Kategori;
import com.serifgungor.bilmeceler.R;

public class BilmecelerActivity extends AppCompatActivity {

    //https://play.google.com/store/apps/details?id=com.snstu.bilmecelervecevaplari

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilmeceler);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        setTitle(kategori.getBaslik());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
